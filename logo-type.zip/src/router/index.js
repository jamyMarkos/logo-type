import { createRouter, createWebHistory } from "vue-router";

import dashboard from "../views/dashboard.vue";
import generateArticle from "../views/generateArticle.vue";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: "/",
      name: "dashboard",
      component: dashboard,
    },
    {
      path: "/generate-article",
      name: "generate-article",
      component: generateArticle,
    },
  ],
});

export default router;
