<script setup></script>

<template>
  <div class="font-[poppins]">
    <router-view />
  </div>
</template>

<style scoped></style>
