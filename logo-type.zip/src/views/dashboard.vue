<template>
  <div class="bg-gray-100">
    <Topnav />
    <div class="px-8 py-6">
      <div class="flex items-center justify-start py-4">
        <h1
          class="text-3xl text-gradient bg-gradient-to-r from-[#0053CD] to-[#4D98FF] font-semibold"
        >
          Hello, Wilson!
        </h1>
      </div>
      <div class="flex items-start gap-6 py-4 pt-8">
        <div class="w-[60%] bg-white rounded-xl py-4 px-6 shadow-md">
          <h2
            class="text-base font-medium text-gradient bg-gradient-to-r from-[#0053CD] to-[#4D98FF]"
          >
            Suggested for You
          </h2>
          <div class="py-2 grid grid-cols-3 gap-x-2">
            <DashboardCards
              v-for="(card, index) in cardData"
              :card="card"
              :key="index"
            />
          </div>
        </div>
        <div
          class="w-[40%] h-[215px] bg-white rounded-xl py-4 px-6 shadow-md"
        ></div>
      </div>
      <div>
        <RecentArticles />
      </div>
    </div>
  </div>
</template>

<script setup>
import Topnav from "../components/common/Topnav.vue";
import RecentArticles from "../components/table/RecentArticles.vue";
import DashboardCards from "../components/UI/DashboardCards.vue";
import { ref } from "vue";

const cardData = (ref([]).value = [
  {
    title: "Generate Article",
    icon: "lucide:wand-sparkles",
  },
  {
    title: "Rewrite Article",
    icon: "lets-icons:edit-light",
  },
  {
    title: "Summary",
    icon: "system-uicons:document",
  },
  {
    title: "Bulk Generate Article",
    icon: "fluent:document-copy-16-regular",
  },
  {
    title: "Rephrase Sections",
    icon: "material-symbols-light:edit-square-outline-rounded",
  },
]);
</script>

<style lang="scss" scoped></style>
