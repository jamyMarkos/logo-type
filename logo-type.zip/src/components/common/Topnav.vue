<template>
  <header>
    <nav
      class="fixed w-full z-50 top-0 flex items-center justify-between px-8 py-3 shadow bg-white"
    >
      <div>
        <img src="/img/logo.svg" alt="Logo" class="h-8 w-auto" />
      </div>
      <ul class="flex items-center justify-between w-2/3">
        <li class="relative w-[50%]">
          <Icon
            icon="ic:baseline-search"
            class="text-[#06041980] text-xl absolute top-2.5 left-3"
          />
          <input
            type="text"
            class="text-sm py-3 text-[#06041980] leading-4 border w-full outline-none pl-10 rounded-3xl px-3 focus:outline-none focus:ring-1 focus:ring-blue-300/70 bg-gray-100/70"
            placeholder="Search in tools..."
          />
          <Icon
            icon="fe:equalizer"
            class="text-gray-400 font-bold text-xl cursor-pointer absolute top-2.5 right-2"
          />
        </li>
        <li
          class="relative w-10 h-10 rounded-full cursor-pointer bg-gray-200 border-none flex items-center justify-center"
        >
          <Icon
            icon="lets-icons:message-light"
            class="text-2xl text-[#06041980ss] text-blue-700 font-extrabold"
          />
          <span
            class="absolute -top-[5px] -right-1.5 w-[18px] h-[18px] rounded-full text-[10px] flex items-center justify-center text-white bg-[#EB2C38]"
            >1</span
          >
        </li>
      </ul>
    </nav>
  </header>
</template>

<script setup>
import { Icon } from "@iconify/vue";
</script>

<style lang="scss" scoped></style>
