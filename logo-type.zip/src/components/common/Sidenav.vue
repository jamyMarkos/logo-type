<template>
  <div class="bg-[#f8f8f8] w-10">
    <h1>This is the sidenav</h1>
  </div>
</template>

<script>
export default {
  setup() {
    return {};
  },
};
</script>

<style lang="scss" scoped></style>
