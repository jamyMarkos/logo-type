<template>
  <div
    class="px-4 sm:px-6 lg:px-8 bg-white rounded-xl shadow-md pt-4 py-2 font-[poppins]"
  >
    <div class="sm:flex sm:items-center">
      <div class="sm:flex-auto">
        <h1
          class="text-base leading-6 text-gradient bg-gradient-to-r from-[#0053CD] to-[#4D98FF] font-semibold"
        >
          Recent Articles
        </h1>
      </div>
    </div>
    <div class="mt-8 flow-root">
      <div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
        <div class="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
          <table class="mytable min-w-full divide-y divide-gray-300">
            <thead>
              <tr class="">
                <th
                  v-for="(header, index) in headers"
                  :key="index"
                  scope="col"
                  class="py-3 pl-4 pr-3 text-left text-xs font-normal capitalize tracking-wide text-gray-500 sm:pl-0"
                >
                  <div class="flex items-center gap-x-2">
                    <p class="text-sm">{{ header.name }}</p>
                    <Icon icon="uil:sort" class="text-sm cursor-pointer" />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 bg-white">
              <tr
                v-for="(data, index) in tableData"
                :key="index"
                class="border-none cursor-pointer"
              >
                <td class="whitespace-nowrap py-4 pl-4 pr-3 sm:pl-0">
                  <div class="flex items-center gap-x-2 text-[#060419CC]">
                    <Icon
                      icon="iconamoon:file-document-thin"
                      class="text-xl font-bold text-[#060419CC]"
                    />
                    <p class="text-sm text-[#060419CC]">
                      {{ data.name }}
                    </p>
                  </div>
                </td>
                <td
                  class="whitespace-nowrap px-3 py-4 text-sm text-[#060419CC]"
                >
                  {{ data.createdOn }}
                </td>
                <td
                  class="whitespace-nowrap px-3 py-4 text-sm text-[#060419CC]"
                >
                  {{ data.lastModified }}
                </td>
                <td
                  class="whitespace-nowrap text-left px-3 py-4 text-sm text-[#060419CC]"
                >
                  {{ data.authorName }}
                </td>
                <td
                  class="whitespace-nowrap py-4 px-3 text-left text-sm text-[#060419CC] sm:pr-0"
                >
                  {{ data.reviewerName }}
                </td>
                <td
                  class="relative text-left whitespace-nowrap py-4 px-3 text-sm font-medium sm:pr-0"
                >
                  <button
                    :class="`px-3 py-2 text-sm font-light text-center rounded-2xl ${
                      data.status === 'Reviewed'
                        ? 'text-[#599FFF] bg-[#5598E71A]'
                        : data.status === 'Completed'
                        ? 'text-[#00B287] bg-[#EEF8F6]'
                        : 'text-[#FF8F69] bg-[#FFF5F4]'
                    }`"
                  >
                    {{ data.status }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <template>
          <div></div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { Icon } from "@iconify/vue";

const headers = (ref([]).value = [
  {
    name: "Name",
    icon: "uil:sort",
  },
  {
    name: "Created on",
    icon: "uil:sort",
  },
  {
    name: "Last Modified",
    icon: "uil:sort",
  },
  {
    name: "Author Name",
    icon: "uil:sort",
  },
  {
    name: "Reviewer Name",
    icon: "uil:sort",
  },
  {
    name: "Status",
    icon: "uil:sort",
  },
]);

const tableData = (ref([]).value = [
  {
    name: "The Transformation of Modern Youth: Impact of Technology on Identity",
    createdOn: "01/15/24",
    lastModified: "2 days ago",
    authorName: "October Trevors",
    reviewerName: "Adam Randols",
    status: "Reviewed",
  },
  {
    name: "The Transformation of Modern Youth: Impact of Technology on Identity",
    createdOn: "01/15/24",
    lastModified: "2 days ago",
    authorName: "October Trevors",
    reviewerName: "Adam Randols",
    status: "Completed",
  },
  {
    name: "The Transformation of Modern Youth: Impact of Technology on Identity",
    createdOn: "01/15/24",
    lastModified: "2 days ago",
    authorName: "October Trevors",
    reviewerName: "Adam Randols",
    status: "Under Review",
  },
  {
    name: "The Transformation of Modern Youth: Impact of Technology on Identity",
    createdOn: "01/15/24",
    lastModified: "2 days ago",
    authorName: "October Trevors",
    reviewerName: "Adam Randols",
    status: "Under Review",
  },
  {
    name: "The Transformation of Modern Youth: Impact of Technology on Identity",
    createdOn: "01/15/24",
    lastModified: "2 days ago",
    authorName: "October Trevors",
    reviewerName: "Adam Randols",
    status: "Completed",
  },
  {
    name: "The Transformation of Modern Youth: Impact of Technology on Identity",
    createdOn: "01/15/24",
    lastModified: "2 days ago",
    authorName: "October Trevors",
    reviewerName: "Adam Randols",
    status: "Reviewed",
  },
]);

const people = [
  {
    name: "Lindsay Walton",
    title: "Front-end Developer",
    email: "lindsay.walton@example.com",
    role: "Member",
  },
  // More people...
];
</script>

<script setup></script>

<style lang="scss" scoped></style>
